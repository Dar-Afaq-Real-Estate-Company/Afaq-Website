@extends('layouts.app')

@section('content')

<main class="section-pad">
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <!-- Card -->
            <div class="card shadow-lg border-0 rounded-4 p-4 fancy-card">
                <div class="text-center mb-4">
                    <h3 class="fw-bold text-white">🔒 {{ __('auth.Reset Password') }}</h3>
                    <p class="text-white-50">{{ __('auth.Enter your email and new password to update your account.') }}</p>
                </div>

                <div class="card-body">
                    <form method="POST" action="{{ route('password.update') }}" id="resetPasswordForm">
                        @csrf
                        <input type="hidden" name="token" value="{{ $token }}">

                        <!-- Email -->
                        <div class="mb-3 position-relative">
                            <label for="email" class="form-label fw-semibold text-white">{{ __('auth.Email') }}</label>
                            <input id="email" type="email"
                                class="form-control rounded-3 p-3 shadow-sm @error('email') is-invalid @enderror"
                                name="email" value="{{ $email ?? old('email') }}" required autocomplete="email" autofocus
                                placeholder="example@email.com">
                            @error('email')
                                <span class="invalid-feedback d-block mt-1 text-black" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <!-- Password -->
                        <div class="mb-3 position-relative">
                            <label for="password" class="form-label fw-semibold text-white">{{ __('auth.New Password') }}</label>
                            <div class="password-wrapper">
                                <input id="password" type="password"
                                    class="form-control rounded-3 p-3 shadow-sm @error('password') is-invalid @enderror"
                                    name="password" required autocomplete="new-password"
                                    placeholder="••••••••">
                                <span class="show-btn" data-target="password">
                                    <i class="fa-regular fa-eye"></i>
                                </span>
                            </div>
                            @error('password')
                                <span class="invalid-feedback d-block mt-1 text-black" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <!-- Confirm Password -->
                        <div class="mb-4 position-relative">
                            <label for="password-confirm" class="form-label fw-semibold text-white">{{ __('auth.Confirm Password') }}</label>
                            <div class="password-wrapper">
                                <input id="password-confirm" type="password"
                                    class="form-control rounded-3 p-3 shadow-sm"
                                    name="password_confirmation" required autocomplete="new-password"
                                    placeholder="••••••••">
                                <span class="show-btn" data-target="password-confirm">
                                    <i class="fa-regular fa-eye"></i>
                                </span>
                            </div>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn fw-bold text-white px-5 py-2 rounded-3 shadow fancy-submit">
                                {{ __('auth.Reset Now') }}
                            </button>
                        </div>

                    </form>
                </div>
            </div>
            <!-- /Card -->

        </div>
    </div>
</div>
</main>

<style>
/* ================= Card ================= */
.fancy-card {
    background: linear-gradient(145deg, #0f4051, #2c6b85);
    box-shadow: 0 25px 60px rgba(15,64,81,0.4);
    border-radius: 20px;
    transition: transform 0.4s, box-shadow 0.4s;
}
.fancy-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 35px 70px rgba(15,64,81,0.6);
}

/* ================= Inputs ================= */
.password-wrapper {
    position: relative;
}
.password-wrapper .show-btn {
    position: absolute;
    top: 50%;
    right: 15px;
    transform: translateY(-50%);
    cursor: pointer;
    color: #0f4051;
    font-size: 1.1rem;
    user-select: none;
}
.password-wrapper input {
    padding-right: 45px;
}
.form-control {
    background-color: #ffffff;
    color: #0f4051;
    border: 1px solid #0f4051;
    border-radius: 10px;
    transition: all 0.3s ease;
}
.form-control:focus {
    border-color: #2c6b85;
    box-shadow: 0 2px 10px rgba(15,64,81,0.3);
}

/* ================= Submit Button ================= */
.fancy-submit {
    background: linear-gradient(135deg, #0f4051, #2c6b85);
    color: #ffffff;
    font-size: 16px;
    font-weight: 700;
    padding: 12px 0;
    border-radius: 12px;
    transition: all 0.4s ease;
    box-shadow: 0 8px 20px rgba(15,64,81,0.6);
}
.fancy-submit:hover {
    box-shadow: 0 12px 28px rgba(15,64,81,0.8);
    transform: translateY(-3px);
}

/* Responsive */
@media(max-width:576px){
    .row > .col-md-8 {flex:0 0 100%; max-width:100%;}
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {

    // Toggle password visibility
    document.querySelectorAll('.show-btn').forEach(function(btn){
        btn.addEventListener('click', function(){
            const target = document.getElementById(this.dataset.target);
            if(target.type === 'password'){
                target.type = 'text';
                this.querySelector('i').classList.remove('fa-eye');
                this.querySelector('i').classList.add('fa-eye-slash');
            } else {
                target.type = 'password';
                this.querySelector('i').classList.remove('fa-eye-slash');
                this.querySelector('i').classList.add('fa-eye');
            }
        });
    });

});
</script>

@endsection
