@extends('layouts.app')

@section('content')

<main class="section-pad">
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <!-- Card -->
            <div class="card shadow-lg border-0 rounded-4 p-4 fancy-card">
                <div class="text-center mb-4">
                    <h3 class="fw-bold text-white">🔑 {{ __('auth.Reset Password') }}</h3>
                    <p class="text-white-50">{{ __('auth.Enter your email to receive a password reset link.') }}</p>
                </div>

                <div class="card-body">

                    @if (session('status'))
                        <div class="alert alert-success text-center fw-semibold" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <form method="POST" action="{{ route('password.email') }}" id="forgotPasswordForm">
                        @csrf

                        <div class="mb-4 position-relative">
                            <label for="email" class="form-label fw-semibold text-white">{{ __('auth.Email') }}</label>
                            <input id="email" type="email"
                                class="form-control rounded-3 p-3 shadow-sm @error('email') is-invalid @enderror"
                                name="email" value="{{ old('email') }}" required autocomplete="email" autofocus
                                placeholder="example@email.com">
                            @error('email')
                                <span class="invalid-feedback d-block mt-1 text-black" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn fw-bold text-white px-5 py-2 rounded-3 shadow fancy-submit">
                                {{ __('auth.Send Reset Link') }}
                            </button>
                        </div>
                    </form>

                    <div class="text-center mt-4">
                        <a href="{{ route('login') }}" class="text-decoration-none text-white">
                            ← {{ __('auth.Back to Login') }}
                        </a>
                    </div>

                </div>
            </div>
            <!-- /Card -->

        </div>
    </div>
</div>
</main>

<style>
/* ================= Card ================= */
.fancy-card {
    background: linear-gradient(145deg, #0f4051, #2c6b85);
    box-shadow: 0 25px 60px rgba(15,64,81,0.4);
    border-radius: 20px;
    transition: transform 0.4s, box-shadow 0.4s;
}
.fancy-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 35px 70px rgba(15,64,81,0.6);
}

/* ================= Inputs ================= */
.form-control {
    background-color: #ffffff;
    color: #0f4051;
    border: 1px solid #0f4051;
    border-radius: 10px;
    padding: 12px 14px;
    transition: all 0.3s ease;
}
.form-control:focus {
    border-color: #2c6b85;
    box-shadow: 0 0 8px rgba(15,64,81,0.3);
}

/* ================= Submit Button ================= */
.fancy-submit {
    background: linear-gradient(135deg, #0f4051, #2c6b85);
    color: #ffffff;
    font-size: 16px;
    font-weight: 700;
    padding: 12px 0;
    border-radius: 12px;
    transition: all 0.4s ease;
    box-shadow: 0 8px 20px rgba(15,64,81,0.6);
}
.fancy-submit:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 28px rgba(15,64,81,0.8);
}

/* ================= Links ================= */
a {
    color: #ffffff !important;
    transition: color 0.3s;
}
a:hover {
    color: #CBA135 !important;
}

/* ================= Responsive ================= */
@media(max-width:576px){
    .row > .col-md-8 {flex:0 0 100%; max-width:100%;}
}
</style>

@endsection
