@extends('layouts.app')

@section('content')
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.2, user-scalable=yes">

<main class="section-pad">
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <!-- Card -->
            <div class="card shadow-lg border-0 rounded-4 p-4 fancy-card">
                <div class="text-center mb-4">
                    <h3 class="fw-bold" style="color:#ffffff; font-size:28px;">{{trans('auth.Login')}}</h3>
                </div>

                <div class="card-body">
                    <form method="POST" action="{{ route('login') }}">
                        @csrf

                        <div class="mb-3">
                            <label for="email" class="form-label fw-bold text-white">{{trans('auth.Email')}}</label>
                            <input id="email" type="email" class="form-control fancy-input @error('email') is-invalid @enderror rounded-3" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong class="text-white">{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
 
                        <div class="mb-3">
                            <label for="password" class="form-label fw-bold text-white">{{trans('auth.password')}}</label>
                            <input id="password" type="password" class="form-control fancy-input @error('password') is-invalid @enderror rounded-3" name="password" required autocomplete="current-password">
                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong class="text-white">{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                            <label class="form-check-label fw-bold text-white" for="remember">{{trans('auth.Remember Me')}}</label>
                        </div>

                        <div class="d-grid gap-3 mt-3">
                            <button type="submit" class="btn fancy-submit">
                                {{trans('auth.Login')}}
                            </button>

                            @if (Route::has('password.request'))
                                <a class="text-center text-white d-block mt-1" href="{{ route('password.request') }}">
                                      {{trans('auth.Forgot Your Password?')}}
                                </a>
                            @endif
                        </div>

                    </form>
                </div>
            </div>
            <!-- /Card -->

        </div>
    </div>
</div>
</main>

<style>
/* الكارد */
.fancy-card {
    background-color: #0f4051;
    box-shadow: 0 25px 60px rgba(15,64,81,0.4);
    border-radius: 20px;
    transition: transform 0.4s, box-shadow 0.4s;
    color: #ffffff;
}
.fancy-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 35px 70px rgba(15,64,81,0.6);
}

/* حقول الإدخال */
.fancy-input {
    background-color: #ffffff;
    color: #0f4051; /* يبقى النص داخل الحقل أسود للوضوح */
    border: 1px solid #0f4051;
    border-radius: 10px;
    padding: 10px 12px;
    transition: all 0.3s ease;
}
.fancy-input:focus {
    border-color: #0f4051;
    box-shadow: 0 2px 10px rgba(15,64,81,0.3);
}

/* زر الدخول */
.fancy-submit {
    background: linear-gradient(135deg, #0f4051, #2c6b85);
    color: #ffffff;
    font-size: 16px;
    font-weight: 700;
    padding: 14px 0;
    border-radius: 12px;
    transition: all 0.4s ease;
    box-shadow: 0 8px 20px rgba(15,64,81,0.6);
}
.fancy-submit:hover {
    box-shadow: 0 12px 28px rgba(15,64,81,0.8);
    transform: translateY(-3px);
}

/* الروابط */
a {
    color: #ffffff !important;
}

/* Responsive */
@media(max-width:576px){
    .row > .col-md-6 {flex:0 0 100%; max-width:100%;}
}
</style>
@endsection
