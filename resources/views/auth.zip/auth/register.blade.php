@extends('layouts.app')

@section('content')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">

<main class="section-pad">
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-8">

            <!-- Card --> <!-- الرسائل -->

            <div class="card shadow-lg border-0 rounded-4 p-4 fancy-card">
                <div class="text-center mb-4">
                    <h3 class="fw-bold text-white">{{trans('auth.Register')}}</h3>
                    <p class="text-white-50">{{trans('auth.Enter your data to create a new account')}}</p>
                </div>

                <div class="card-body">
                    <form method="POST" action="{{ route('register') }}" id="registerForm">
                        @csrf
@if(session('error'))
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>خطأ!</strong> {{ session('error') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
@endif

@if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
@endif


  
                        <!-- الاسم الأول واسم العائلة -->
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold text-white">{{trans('auth.first_name')}}</label>
                                <input type="text" name="name" class="form-control fancy-input" placeholder="{{trans('auth.first_name')}}" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold text-white">{{trans('auth.last_name')}}</label>
                                <input type="text" name="last_name" class="form-control fancy-input" placeholder="{{trans('auth.last_name')}}" required>
                            </div>
                        </div>

                        <!-- البريد الإلكتروني -->
                        <div class="mb-3">
                            <label class="form-label fw-bold text-white">{{trans('auth.Email')}}</label>
                            <input type="email" name="email" class="form-control fancy-input" placeholder="example@domain.com" required>
                        </div>

                        <!-- الهاتف -->
                        <div class="mb-3">
                            <label class="form-label fw-bold text-white">{{trans('auth.phone')}}</label>
                            <input type="text" name="phone" class="form-control fancy-input" placeholder="xxxxxxxxx" required>
                        </div>

                        <hr class="my-4 border-white">
<div class="mb-3">
    <label class="form-label fw-bold text-white">كلمة المرور</label>
    <div class="password-wrapper">
        <input type="password" id="password" name="password" class="form-control fancy-input" placeholder="********" required>
        <span class="toggle-password" data-target="password">
            <i class="fa fa-eye"></i>
        </span>
    </div>
</div>

<div class="mb-3">
    <label class="form-label fw-bold text-white">تأكيد كلمة المرور</label>
    <div class="password-wrapper">
        <input type="password" id="password_confirmation" name="password_confirmation" class="form-control fancy-input" placeholder="********" required>
        <span class="toggle-password" data-target="password_confirmation">
            <i class="fa fa-eye"></i>
        </span>
    </div>
</div>





                        <!-- زر التسجيل -->
                        <div class="d-grid gap-3 mt-4">
                            <button type="submit" class="btn fancy-submit">
                                {{trans('auth.Register')}}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <!-- /Card -->
        </div>
    </div>
</div>
</main>

<style>
/* الكارد */
.fancy-card {
    background: linear-gradient(145deg, #0f4051, #ffffff);
    box-shadow: 0 25px 60px rgba(15,64,81,0.4);
    border-radius: 20px;
    transition: transform 0.4s, box-shadow 0.4s;
    color: #ffffff;
}
.fancy-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 35px 70px rgba(15,64,81,0.6);
}

/* حقول الإدخال */
.fancy-input {
    background-color: #ffffff;
    color: #0f4051;
    border: 1px solid #0f4051;
    border-radius: 10px;
    padding: 10px 12px;
    transition: all 0.3s ease;
}
.fancy-input:focus {
    border-color: #0f4051;
    box-shadow: 0 2px 10px rgba(15,64,81,0.3);
}

/* زر التسجيل */
.fancy-submit {
    background: linear-gradient(135deg, #0f4051, #2c6b85);
    color: #ffffff;
    font-size: 16px;
    font-weight: 700;
    padding: 14px 0;
    border-radius: 12px;
    transition: all 0.4s ease;
    box-shadow: 0 8px 20px rgba(15,64,81,0.6);
}
.fancy-submit:hover {
    box-shadow: 0 12px 28px rgba(15,64,81,0.8);
    transform: translateY(-3px);
}

/* Responsive */
@media(max-width:576px){
    .row > .col-md-6 {flex:0 0 100%; max-width:100%;}
}





/* حقل الباسورد */
.fancy-input {
    width: 100%;
    padding: 10px 45px 10px 12px; /* مساحة للأيقونة على اليمين */
    border-radius: 12px;
    border: 1px solid #0f4051;
    background-color: #ffffff;
    color: #0f4051;
    transition: all 0.3s ease;
    box-sizing: border-box;
}

/* أيقونة العين */
.toggle-password {
    position: absolute;
    top: 50%;
    right: 12px;
    transform: translateY(-50%);
    cursor: pointer;
    z-index: 2;
    font-size: 1.2rem;
    color: #0f4051;
    transition: color 0.3s;
}

.toggle-password:hover {
    color: #CBA135;
}

.password-wrapper {
    position: relative;
}

.fancy-input {
    width: 100%;
    padding: 10px 45px 10px 12px; /* مساحة للأيقونة على اليمين */
    border-radius: 12px;
    border: 1px solid #0f4051;
    background-color: #ffffff;
    color: #0f4051;
    box-sizing: border-box;
    font-size: 1rem;
}

/* الأيقونة ثابتة في منتصف ارتفاع الحقل */
.toggle-password {
    position: absolute;
    top: 50%;
    right: 12px; /* مسافة من حافة الحقل اليمنى */
    transform: translateY(-50%);
    cursor: pointer;
    z-index: 2;
    font-size: 1.2rem; /* حجم الأيقونة */
    color: #0f4051;
    transition: color 0.3s;
}

.toggle-password:hover {
    color: #CBA135;
}

</style>

<script>
document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', function () {
        const input = document.getElementById(this.dataset.target);
        const icon = this.querySelector('i');

        if(input.type === "password") {
            input.type = "text";
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash'); // عين مغلقة
        } else {
            input.type = "password";
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye'); // عين مفتوحة
        }
    });
});



</script>


<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('registerForm');
    form.addEventListener('submit', function(e){
        if(!form.checkValidity()){
            e.preventDefault();
            e.stopPropagation();
            alert("يرجى تعبئة جميع الحقول بشكل صحيح!");
        }
        form.classList.add('was-validated');
    });
});
</script>

@endsection
